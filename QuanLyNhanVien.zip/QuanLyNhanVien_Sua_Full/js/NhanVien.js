function NhanVien(_maNV, _tenNV, _email, _password, _date, _chucVu) {
  //Key: value
  this.maNV = _maNV;
  this.tenNV = _tenNV;
  this.email = _email;
  this.password = _password;
  this.date = _date;
  this.chucVu = _chucVu;
}
